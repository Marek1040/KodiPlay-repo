"""Úložisko rozpozeraných (continue watching) — JSON v addon_data.

Sleduje: ident, názov, plagát, sub_query, pozícia, dĺžka, čas.
"""
import json
import time

import xbmcaddon
import xbmcvfs

_ADDON = xbmcaddon.Addon()
_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_SUBOR = _DIR + "watched.json"


def _nacitaj_raw():
    try:
        if xbmcvfs.exists(_SUBOR):
            with xbmcvfs.File(_SUBOR) as f:
                return json.loads(f.read() or "{}")
    except Exception:
        pass
    return {}


def _zapis(data):
    try:
        if not xbmcvfs.exists(_DIR):
            xbmcvfs.mkdirs(_DIR)
        with xbmcvfs.File(_SUBOR, "w") as f:
            f.write(bytearray(json.dumps(data).encode("utf-8")))
    except Exception:
        pass


def uloz(ident, nazov, plagat, sub, position, total,
         tmdb_id="", media_type="", en="", rok="", fanart=""):
    if not ident:
        return
    data = _nacitaj_raw()
    finished = total > 0 and position >= total * 0.92
    if finished:
        data.pop(ident, None)  # dopozerané → preč z rozpozeraných
    else:
        data[ident] = {
            "ident": ident, "nazov": nazov, "plagat": plagat, "sub": sub,
            "position": int(position), "total": int(total), "cas": time.time(),
            "tmdb_id": tmdb_id, "media_type": media_type, "en": en, "rok": rok,
            "fanart": fanart,
        }
    _zapis(data)


def zoznam():
    """Rozpozerané položky, najnovšie prvé (len s rozumnou pozíciou)."""
    data = _nacitaj_raw()
    polozky = [v for v in data.values() if v.get("position", 0) > 30]
    polozky.sort(key=lambda x: x.get("cas", 0), reverse=True)
    return polozky


def odstran(ident):
    data = _nacitaj_raw()
    if data.pop(ident, None) is not None:
        _zapis(data)


# ── Watchlist (Moje) + seed pre odporúčania ──────────────────────────────────

_FAV = _DIR + "favourites.json"


def _nacitaj(subor):
    try:
        if xbmcvfs.exists(subor):
            with xbmcvfs.File(subor) as f:
                return json.loads(f.read() or "{}")
    except Exception:
        pass
    return {}


def _uloz_json(subor, data):
    try:
        if not xbmcvfs.exists(_DIR):
            xbmcvfs.mkdirs(_DIR)
        with xbmcvfs.File(subor, "w") as f:
            f.write(bytearray(json.dumps(data).encode("utf-8")))
    except Exception:
        pass


def _fav_kluc(p):
    return str(p.get("tmdb_id") or p.get("en") or p.get("nazov") or "")


def oblubene_pridaj(polozka):
    kluc = _fav_kluc(polozka)
    if not kluc:
        return
    data = _nacitaj(_FAV)
    polozka = dict(polozka)
    polozka["cas"] = time.time()
    data[kluc] = polozka
    _uloz_json(_FAV, data)


def oblubene_odstran(kluc):
    data = _nacitaj(_FAV)
    if data.pop(str(kluc), None) is not None:
        _uloz_json(_FAV, data)


def oblubene_je(kluc):
    return str(kluc) in _nacitaj(_FAV)


def oblubene_zoznam():
    p = list(_nacitaj(_FAV).values())
    p.sort(key=lambda x: x.get("cas", 0), reverse=True)
    return p


def seed_odporucania():
    """Najnovší titul s tmdb_id (z obľúbených alebo rozpozeraných) pre 'Pretože si pozeral'."""
    kandidati = [k for k in (oblubene_zoznam() + list(_nacitaj_raw().values()))
                 if k.get("tmdb_id")]
    kandidati.sort(key=lambda x: x.get("cas", 0), reverse=True)
    return kandidati[0] if kandidati else None
