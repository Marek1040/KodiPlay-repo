"""KodiPlay service — sleduje prehrávanie, ukladá pozíciu (rozpozerané) a
autoplay ďalšej epizódy (Netflix-style binge).

Číta window properties nastavené pri spustení (KodiPlay.*), priebežne + pri
zastavení ukladá pozíciu do watched.json a po dopozeraní epizódy spustí ďalšiu.
"""
import xbmc
import xbmcgui

from resources.lib import store

WIN = xbmcgui.Window(10000)


class Prehravac(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.aktivny = None

    def _zisti_kontext(self):
        ident = WIN.getProperty('KodiPlay.ident')
        if ident:
            self.aktivny = {
                'ident': ident,
                'nazov': WIN.getProperty('KodiPlay.nazov'),
                'plagat': WIN.getProperty('KodiPlay.plagat'),
                'fanart': WIN.getProperty('KodiPlay.fanart'),
                'sub': WIN.getProperty('KodiPlay.sub'),
                'tmdb': WIN.getProperty('KodiPlay.tmdb'),
                'mtype': WIN.getProperty('KodiPlay.mtype'),
                'en': WIN.getProperty('KodiPlay.en'),
                'rok': WIN.getProperty('KodiPlay.rok'),
                'dalsia': WIN.getProperty('KodiPlay.dalsia'),
            }
            WIN.clearProperty('KodiPlay.ident')  # aby to nededilo ďalšie prehrávanie
        else:
            self.aktivny = None

    def onAVStarted(self):
        self._zisti_kontext()

    def onPlayBackStarted(self):
        if self.aktivny is None:
            self._zisti_kontext()

    def _uloz(self, pos, total):
        a = self.aktivny
        store.uloz(a['ident'], a['nazov'], a['plagat'], a['sub'], pos, total,
                   tmdb_id=a.get('tmdb', ''), media_type=a.get('mtype', ''),
                   en=a.get('en', ''), rok=a.get('rok', ''), fanart=a.get('fanart', ''))

    def uloz_poziciu(self):
        if not self.aktivny:
            return
        try:
            pos = self.getTime()
            total = self.getTotalTime()
        except Exception:
            return
        if total > 0:
            self._uloz(pos, total)

    def onPlayBackStopped(self):
        self.aktivny = None  # manuálne zastavené → žiadny autoplay

    def onPlayBackEnded(self):
        if not self.aktivny:
            return
        self._uloz(999999, 1000000)  # dopozerané → preč z rozpozeraných
        dalsia = self.aktivny.get('dalsia')
        self.aktivny = None
        if dalsia:  # Netflix-style autoplay ďalšej epizódy
            xbmc.executebuiltin('PlayMedia(%s)' % dalsia)


monitor = xbmc.Monitor()
player = Prehravac()

while not monitor.abortRequested():
    try:
        if player.isPlayingVideo() and player.aktivny:
            player.uloz_poziciu()
    except Exception:
        pass
    if monitor.waitForAbort(15):
        break
