"""KodiPlay — Kodi addon. Webshare.cz vyhľadávanie a prehrávanie priamo v Kodi.

Menu: Filmy / Seriály / TV / Hľadať / Rozpozerané / Nastavenia.
Filmy a Seriály majú podmenu (Populárne / Trending / Očakávané).
"""
import sys
import re
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from resources.lib import webshare
from resources.lib import tmdb
from resources.lib import trakt
from resources.lib import opensubtitles
from resources.lib import tv
from resources.lib import store

_HANDLE = int(sys.argv[1])
_URL = sys.argv[0]
_ADDON = xbmcaddon.Addon()
_WIN = xbmcgui.Window(10000)


def _link(**kwargs):
    return _URL + '?' + urlencode(kwargs)


def _s(key, default=''):
    try:
        return _ADDON.getSetting(key) or default
    except Exception:
        return default


def _notif(sprava, chyba=False, cas=4000):
    xbmcgui.Dialog().notification('KodiPlay', sprava,
                                  xbmcgui.NOTIFICATION_ERROR if chyba else xbmcgui.NOTIFICATION_INFO, cas)


def _polozka(nazov, url, ikona, folder=True):
    li = xbmcgui.ListItem(label=nazov)
    li.setArt({'icon': ikona, 'thumb': ikona})
    xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=folder)


# ── Hlavné menu ───────────────────────────────────────────────────────────────

def hlavne_menu():
    xbmcplugin.setPluginCategory(_HANDLE, 'KodiPlay')
    xbmcplugin.setContent(_HANDLE, 'videos')
    _polozka('Filmy',        _link(action='menu_filmy'),   'DefaultMovies.png')
    _polozka('Seriály',      _link(action='menu_serialy'), 'DefaultTVShows.png')
    _polozka('TV',           _link(action='tv'),           'DefaultAddonPVRClient.png')
    _polozka('Hľadať',       _link(action='hladat'),       'DefaultAddonsSearch.png')
    _polozka('Rozpozerané',  _link(action='rozpozerane'),  'DefaultInProgressShows.png')
    _polozka('Moje',         _link(action='moje'),         'DefaultPlaylist.png')
    _polozka('Odporúčané',   _link(action='odporucane'),   'DefaultFavourites.png')
    _polozka('Nastavenia',   _link(action='nastavenia'),   'DefaultAddonService.png')
    xbmcplugin.endOfDirectory(_HANDLE)


def menu_filmy():
    xbmcplugin.setPluginCategory(_HANDLE, 'Filmy')
    _polozka('Populárne',   _link(action='trakt', kat='pop_movie'),   'DefaultMovies.png')
    _polozka('Trending',    _link(action='trakt', kat='trend_movie'), 'DefaultMovies.png')
    _polozka('Top 20',      _link(action='trakt', kat='top_movie'),   'DefaultMovies.png')
    _polozka('Očakávané',   _link(action='trakt', kat='antic_movie'), 'DefaultMovies.png')
    _polozka('CZ / SK',     _link(action='trakt', kat='cz_movie'),    'DefaultMovies.png')
    _polozka('Žánre',       _link(action='zanre', typ='movie'),       'DefaultGenre.png')
    xbmcplugin.endOfDirectory(_HANDLE)


def menu_serialy():
    xbmcplugin.setPluginCategory(_HANDLE, 'Seriály')
    _polozka('Populárne', _link(action='trakt', kat='pop_tv'),   'DefaultTVShows.png')
    _polozka('Trending',  _link(action='trakt', kat='trend_tv'), 'DefaultTVShows.png')
    _polozka('Top 20',    _link(action='trakt', kat='top_tv'),   'DefaultTVShows.png')
    _polozka('Očakávané', _link(action='trakt', kat='antic_tv'), 'DefaultTVShows.png')
    _polozka('CZ / SK',   _link(action='trakt', kat='cz_tv'),    'DefaultTVShows.png')
    _polozka('Žánre',     _link(action='zanre', typ='tv'),       'DefaultGenre.png')
    xbmcplugin.endOfDirectory(_HANDLE)


def zanre(typ):
    xbmcplugin.setPluginCategory(_HANDLE, 'Žánre')
    ikona = 'DefaultTVShows.png' if typ == 'tv' else 'DefaultMovies.png'
    for slug, nazov in trakt.ZANRE:
        _polozka(nazov, _link(action='zaner', typ=typ, slug=slug), ikona)
    xbmcplugin.endOfDirectory(_HANDLE)


# ── TV kanály ─────────────────────────────────────────────────────────────────

def tv_kanaly():
    xbmcplugin.setPluginCategory(_HANDLE, 'TV')
    xbmcplugin.setContent(_HANDLE, 'videos')
    for ch in tv.kanaly():
        li = xbmcgui.ListItem(label=ch['nazov'])
        if ch.get('logo'):
            li.setArt({'icon': ch['logo'], 'thumb': ch['logo']})
        li.setInfo('video', {'title': ch['nazov']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(_HANDLE, _link(action='play_tv', url=ch['url'], nazov=ch['nazov']), li, isFolder=False)
    xbmcplugin.endOfDirectory(_HANDLE)


def play_tv(url, nazov):
    li = xbmcgui.ListItem(path=url)
    li.setInfo('video', {'title': nazov})
    xbmcplugin.setResolvedUrl(_HANDLE, True, li)


# ── Trakt zoznamy ─────────────────────────────────────────────────────────────

def _render_zoznam(polozky, dalsia='', moje_view=False):
    xbmcplugin.setContent(_HANDLE, 'movies')
    for m in polozky:
        rok = str(m.get('rok', ''))
        je_tv = m['media_type'] == 'tv'
        li = xbmcgui.ListItem(label=m['nazov'])
        li.setArt({'poster': m['plagat'], 'thumb': m['plagat'],
                   'fanart': m.get('fanart') or m['plagat']})
        li.setInfo('video', {'title': m['cisty_nazov'], 'plot': m.get('popis', ''),
                             'year': int(rok) if rok.isdigit() else 0,
                             'rating': float(m['rating']) / 10 if m.get('rating') else 0,
                             'mediatype': 'tvshow' if je_tv else 'movie'})
        akcia = 'serial' if je_tv else 'film'
        url = _link(action=akcia, en=m['en_nazov'], rok=rok, nazov=m['cisty_nazov'],
                    plagat=m['plagat'], fanart=m.get('fanart', ''), popis=m.get('popis', ''),
                    tmdb_id=m.get('tmdb_id', ''))
        if moje_view:
            kluc = m.get('tmdb_id') or m.get('en_nazov') or m['cisty_nazov']
            cm = [('Odobrať z „Moje“', 'RunPlugin(%s)' % _link(action='fav_del', kluc=kluc))]
        else:
            cm = [('Pridať do „Moje“', 'RunPlugin(%s)' % _link(
                action='fav_add', tmdb_id=m.get('tmdb_id', ''), en=m['en_nazov'], rok=rok,
                nazov=m['cisty_nazov'], plagat=m['plagat'], fanart=m.get('fanart', ''),
                popis=m.get('popis', ''), mtype=m['media_type']))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=True)
    if dalsia:
        li = xbmcgui.ListItem(label='Ďalšia strana »')
        li.setArt({'icon': 'DefaultFolderBack.png', 'thumb': 'DefaultFolderBack.png'})
        xbmcplugin.addDirectoryItem(_HANDLE, dalsia, li, isFolder=True)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_HANDLE)


def zoznam_trakt(kat, page=1):
    mapa = {
        'pop_movie':   trakt.popularne_filmy,   'trend_movie': trakt.trending_filmy,
        'antic_movie': trakt.anticipovane_filmy, 'top_movie':  trakt.top_filmy,
        'cz_movie':    trakt.cz_sk_filmy,
        'pop_tv':      trakt.popularne_serialy,  'trend_tv':   trakt.trending_serialy,
        'antic_tv':    trakt.anticipovane_serialy, 'top_tv':   trakt.top_serialy,
        'cz_tv':       trakt.cz_sk_serialy,
    }
    fn = mapa.get(kat)
    if not fn:
        hlavne_menu(); return
    dlg = xbmcgui.DialogProgressBG(); dlg.create('KodiPlay', 'Načítavam…')
    polozky = fn(page)
    dlg.close()
    dalsia = _link(action='trakt', kat=kat, page=page + 1) if len(polozky) >= 20 else ''
    _render_zoznam(polozky, dalsia)


def zoznam_zaner(typ, slug, page=1):
    dlg = xbmcgui.DialogProgressBG(); dlg.create('KodiPlay', 'Načítavam žáner…')
    polozky = trakt.serialy_zaner(slug, page) if typ == 'tv' else trakt.filmy_zaner(slug, page)
    dlg.close()
    dalsia = _link(action='zaner', typ=typ, slug=slug, page=page + 1) if len(polozky) >= 20 else ''
    _render_zoznam(polozky, dalsia)


# ── Vyhľadávanie / streamy ────────────────────────────────────────────────────

def hladat():
    kb = xbmc.Keyboard('', 'Zadaj názov filmu alebo seriálu')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(_HANDLE); return
    dopyt = kb.getText().strip()
    d = tmdb.preloz_nazov(dopyt)
    dopyty = []
    if d['en']:
        dopyty += [(d['en'] + ' ' + d['rok']).strip(), d['en']]
    if d['cz'] and d['cz'].lower() != d['en'].lower():
        dopyty += [(d['cz'] + ' ' + d['rok']).strip()]
    if not dopyty:
        dopyty = [dopyt]
    cisty = d['cisty'] or dopyt
    vysledky = _hladaj(dopyty, d['rok'])
    # ak to vyzerá ako seriál (viac epizód), zobraz série; inak ploché streamy
    epiz = [s for s in vysledky if s['sezona'] and s['epizoda']]
    en_base = d['en'] or dopyt
    if len(epiz) >= 3:
        tmdb_id = trakt.najdi_id(en_base, je_tv=True)
        _render_serie(vysledky, en_base, cisty, d['rok'],
                      d['plagat'], d['fanart'], d['popis'], tmdb_id)
    else:
        _render_streamy(vysledky, cisty=cisty, rok=d['rok'], plagat=d['plagat'],
                        fanart=d['fanart'], popis=d['popis'], tmdb_id=d.get('id', ''))


def film(en, rok, nazov, plagat, fanart, popis, tmdb_id=''):
    vysledky = _hladaj([(en + ' ' + rok).strip(), en], rok)
    _render_streamy(vysledky, cisty=nazov, rok=rok, plagat=plagat, fanart=fanart,
                    popis=popis, tmdb_id=tmdb_id, media_type='movie', en=en)


def serial(en, rok, nazov, plagat, fanart, popis, tmdb_id=''):
    # seriál: hľadáme bez roku (epizódy ho nemávajú) a zoskupíme podľa sérií
    vysledky = _hladaj([en], '')
    _render_serie(vysledky, en, nazov, rok, plagat, fanart, popis, tmdb_id)


def serial_seria(en, rok, nazov, plagat, fanart, popis, sezona, tmdb_id=''):
    dopyty = [en] + (['%s S%02d' % (en, sezona)] if sezona else [])
    vysledky = _hladaj(dopyty, '')
    if sezona == 0:  # "Ostatné / balíky" — súbory bez SxxExx
        ostatne = [s for s in vysledky if not (s['sezona'] and s['epizoda'])]
        _render_streamy(ostatne, cisty=nazov, rok=rok, plagat=plagat, fanart=fanart,
                        popis=popis, tmdb_id=tmdb_id, media_type='tv', en=en)
    else:
        _render_epizody(vysledky, sezona, en, nazov, rok, plagat, fanart, popis, tmdb_id)


def epizoda(en, rok, nazov, plagat, fanart, popis, sezona, epiz_c, tmdb_id=''):
    dopyty = [en, '%s S%02dE%02d' % (en, sezona, epiz_c)]
    vysledky = _hladaj(dopyty, '')
    vyb = [s for s in vysledky if s['sezona'] == sezona and s['epizoda'] == epiz_c]
    oznac = '%s S%02dE%02d' % (nazov, sezona, epiz_c)
    # autoplay: kontext ďalšej epizódy
    dalsia = _link(action='prehrat_auto', en=en, rok=rok, nazov=nazov, plagat=plagat,
                   fanart=fanart, popis=popis, tmdb_id=tmdb_id, sezona=sezona, epizoda=epiz_c + 1)
    _render_streamy(vyb, cisty=oznac, rok=rok, plagat=plagat, fanart=fanart, popis=popis,
                    sub_query=oznac, tmdb_id=tmdb_id, media_type='tv', en=en, dalsia=dalsia)


def _hladaj(dopyty, rok):
    """Prehľadá Webshare cez viac dopytov, zlúči (bez duplikátov), zoradí podľa zhody."""
    seen, vysledky = set(), []
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Hľadám na Webshare…')
    for i, q in enumerate(dopyty):
        if dlg.iscanceled():
            break
        dlg.update(int(i / max(1, len(dopyty)) * 100), q)
        for s in webshare.vyhladaj(q, rok):
            if s['ident'] not in seen:
                seen.add(s['ident']); vysledky.append(s)
    dlg.close()
    vysledky.sort(key=lambda x: (round(x.get('relevance', 0), 2), x['analyza']['score']),
                  reverse=True)
    return vysledky


def _art(plagat, fanart, clearlogo='', thumb=None):
    a = {'poster': plagat, 'thumb': thumb or plagat, 'fanart': fanart or plagat}
    if clearlogo:
        a['clearlogo'] = clearlogo
        a['clearart'] = clearlogo
    return a


def _render_serie(vysledky, en, cisty, rok, plagat, fanart, popis, tmdb_id=''):
    """Netflix-style: zoznam sérií (podľa toho, čo je reálne na Webshare)."""
    xbmcplugin.setPluginCategory(_HANDLE, cisty)
    xbmcplugin.setContent(_HANDLE, 'seasons')
    if not vysledky:
        _notif('Nič sa nenašlo (over prihlásenie v Nastaveniach)', chyba=True)
        xbmcplugin.endOfDirectory(_HANDLE); return
    logo = trakt.logo(tmdb_id, True) if tmdb_id else ''
    serie, ostatne = {}, 0
    for s in vysledky:
        if s['sezona'] and s['epizoda']:
            serie.setdefault(s['sezona'], set()).add(s['epizoda'])
        else:
            ostatne += 1
    for sez in sorted(serie):
        li = xbmcgui.ListItem(label='Séria %d  (%d epizód)' % (sez, len(serie[sez])))
        li.setArt(_art(plagat, fanart, logo))
        li.setInfo('video', {'title': 'Séria %d' % sez, 'tvshowtitle': cisty,
                             'season': sez, 'mediatype': 'season', 'plot': popis})
        url = _link(action='serial_seria', en=en, rok=rok, nazov=cisty, plagat=plagat,
                    fanart=fanart, popis=popis, sezona=sez, tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=True)
    if ostatne:
        li = xbmcgui.ListItem(label='Ostatné / balíky  (%d)' % ostatne)
        li.setArt(_art(plagat, fanart, logo))
        url = _link(action='serial_seria', en=en, rok=rok, nazov=cisty, plagat=plagat,
                    fanart=fanart, popis=popis, sezona=0, tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=True)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_HANDLE)


def _render_epizody(vysledky, sezona, en, cisty, rok, plagat, fanart, popis, tmdb_id=''):
    xbmcplugin.setPluginCategory(_HANDLE, '%s — Séria %d' % (cisty, sezona))
    xbmcplugin.setContent(_HANDLE, 'episodes')
    epiz = {}
    for s in vysledky:
        if s['sezona'] == sezona and s['epizoda']:
            epiz[s['epizoda']] = epiz.get(s['epizoda'], 0) + 1
    if not epiz:
        _notif('Pre sériu %d sa nič nenašlo' % sezona, chyba=True)
        xbmcplugin.endOfDirectory(_HANDLE); return
    meta = trakt.tv_epizody(tmdb_id, sezona) if tmdb_id else {}   # názvy/náhľady/popisy epizód
    logo = trakt.logo(tmdb_id, True) if tmdb_id else ''
    for ep in sorted(epiz):
        m = meta.get(ep, {})
        nazov_ep = m.get('nazov') or ('Epizóda %d' % ep)
        still = m.get('still') or plagat
        popis_ep = m.get('popis') or popis
        label = '%dx%02d  %s  (%d streamov)' % (sezona, ep, nazov_ep, epiz[ep])
        li = xbmcgui.ListItem(label=label)
        li.setArt(_art(plagat, fanart, logo, thumb=still))
        info = {'title': nazov_ep, 'tvshowtitle': cisty, 'season': sezona,
                'episode': ep, 'mediatype': 'episode', 'plot': popis_ep}
        if m.get('datum'):
            info['premiered'] = m['datum']
        if m.get('rating'):
            info['rating'] = float(m['rating']) / 10
        li.setInfo('video', info)
        url = _link(action='epizoda', en=en, rok=rok, nazov=cisty, plagat=plagat,
                    fanart=fanart, popis=popis, sezona=sezona, epizoda=ep, tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=True)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_HANDLE)


def _render_streamy(vysledky, cisty, rok, plagat, fanart, popis, sub_query=None,
                    tmdb_id='', media_type='movie', en='', dalsia=''):
    xbmcplugin.setPluginCategory(_HANDLE, 'Streamy: ' + cisty)
    xbmcplugin.setContent(_HANDLE, 'videos')

    if not vysledky:
        _notif('Nič sa nenašlo (over prihlásenie v Nastaveniach)', chyba=True)
        xbmcplugin.endOfDirectory(_HANDLE); return

    logo = trakt.logo(tmdb_id, media_type == 'tv') if tmdb_id else ''
    if sub_query is None:
        sub_query = (cisty + ' ' + rok).strip()
    for s in vysledky:
        a = s['analyza']
        znacky = []
        if s['sezona'] and s['epizoda']:
            znacky.append('S%02dE%02d' % (s['sezona'], s['epizoda']))
        znacky += [a['jazyk'], a['kvalita']]
        if a['kodek']:
            znacky.append(a['kodek'])
        znacky.append('%.1f GB' % a['velkost_gb'])
        plynulost = 'Plynulé ✓' if a.get('plynuly') else 'Môže sekať ⚠'
        znacky.append(plynulost.split()[0])
        li = xbmcgui.ListItem(label='[%s] %s' % (' · '.join(znacky), s['nazov']))
        nahlad = s.get('nahlad') or plagat
        li.setArt(_art(plagat, fanart, logo, thumb=nahlad))
        # Popis streamu (detaily súboru) + popis filmu
        hlasy = ''
        if s.get('plus') or s.get('minus'):
            hlasy = '  (👍 %d / 👎 %d)' % (s.get('plus', 0), s.get('minus', 0))
        detaily = [
            'Súbor: %s' % s['nazov'],
            'Jazyk: %s' % a['jazyk'],
            'Kvalita: %s%s' % (a['kvalita'], ' · ' + a['kodek'] if a['kodek'] else ''),
            'Veľkosť: %.1f GB   Bitrate: ~%.1f Mb/s' % (a['velkost_gb'], a.get('bitrate', 0)),
            'Prehrávanie: %s%s' % (plynulost, hlasy),
        ]
        if s.get('chraneny'):
            detaily.append('⚠ Súbor chránený heslom')
        if s['sezona'] and s['epizoda']:
            detaily.insert(0, 'Epizóda: S%02dE%02d' % (s['sezona'], s['epizoda']))
        plot = '[B]Stream[/B]\n' + '\n'.join(detaily)
        if popis:
            plot += '\n\n[B]Popis[/B]\n' + popis
        li.setInfo('video', {'title': '[%s · %s] %s' % (a['jazyk'], a['kvalita'], cisty),
                             'plot': plot,
                             'year': int(rok) if rok.isdigit() else 0})
        li.setProperty('IsPlayable', 'true')
        url = _link(action='prehrat', ident=s['ident'], nazov=s['nazov'], sub=sub_query,
                    plagat=plagat, fanart=fanart, tmdb_id=tmdb_id, mtype=media_type,
                    en=en, rok=rok, dalsia=dalsia)
        cm = [('Stiahnuť do zariadenia',
               'RunPlugin(%s)' % _link(action='download', ident=s['ident'], nazov=s['nazov']))]
        if en or tmdb_id:
            cm.append(('Pridať do „Moje“', 'RunPlugin(%s)' % _link(
                action='fav_add', tmdb_id=tmdb_id, en=en, rok=rok, nazov=cisty,
                plagat=plagat, fanart=fanart, popis=popis, mtype=media_type)))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=False)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_HANDLE)


def _resolvuj(ident, nazov, sub, plagat, fanart, resume, total,
              tmdb_id, mtype, en, rok, dalsia):
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Získavam odkaz…')
    link = webshare.vip_link(ident)
    dlg.close()
    if not link:
        _notif('Nepodarilo sa získať odkaz (VIP/token?)', chyba=True)
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem()); return

    # Kontext pre service (rozpozerané + autoplay ďalšej epizódy)
    _WIN.setProperty('KodiPlay.ident', ident)
    _WIN.setProperty('KodiPlay.nazov', nazov)
    _WIN.setProperty('KodiPlay.plagat', plagat)
    _WIN.setProperty('KodiPlay.fanart', fanart)
    _WIN.setProperty('KodiPlay.sub', sub)
    _WIN.setProperty('KodiPlay.tmdb', tmdb_id)
    _WIN.setProperty('KodiPlay.mtype', mtype)
    _WIN.setProperty('KodiPlay.en', en)
    _WIN.setProperty('KodiPlay.rok', rok)
    _WIN.setProperty('KodiPlay.dalsia', dalsia or '')

    li = xbmcgui.ListItem(path=link)
    li.setInfo('video', {'title': nazov})
    if plagat:
        li.setArt({'poster': plagat, 'thumb': plagat, 'fanart': fanart or plagat})
    if resume and total:
        li.setProperty('ResumeTime', str(resume))
        li.setProperty('TotalTime', str(total))
    # Titulky cez OpenSubtitles
    if sub and opensubtitles.je_nakonfigurovany():
        try:
            linky = opensubtitles.linky_pre(sub, max_pocet=3)
            if linky:
                li.setSubtitles(linky)
        except Exception:
            pass
    xbmcplugin.setResolvedUrl(_HANDLE, True, li)


def prehrat(ident, nazov, sub='', plagat='', resume=0, total=0,
            tmdb_id='', mtype='', en='', rok='', fanart='', dalsia=''):
    _resolvuj(ident, nazov, sub, plagat, fanart, resume, total,
              tmdb_id, mtype, en, rok, dalsia)


def prehrat_auto(en, rok, nazov, plagat, fanart, popis, tmdb_id, sezona, epiz_c):
    """Autoplay: nájde a prehrá najlepší stream ďalšej epizódy (S{sezona}E{epiz_c})."""
    dopyty = [en, '%s S%02dE%02d' % (en, sezona, epiz_c)]
    vyb = [s for s in _hladaj(dopyty, '')
           if s['sezona'] == sezona and s['epizoda'] == epiz_c]
    if not vyb:
        _notif('Séria skončila — žiadna ďalšia epizóda', cas=3000)
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem()); return
    sub = '%s S%02dE%02d' % (nazov, sezona, epiz_c)
    dalsia = _link(action='prehrat_auto', en=en, rok=rok, nazov=nazov, plagat=plagat,
                   fanart=fanart, popis=popis, tmdb_id=tmdb_id, sezona=sezona, epizoda=epiz_c + 1)
    _resolvuj(vyb[0]['ident'], '%s %dx%02d' % (nazov, sezona, epiz_c), sub, plagat, fanart,
              0, 0, tmdb_id, 'tv', en, rok, dalsia)


# ── Moje (watchlist) + Odporúčané ─────────────────────────────────────────────

def moje():
    xbmcplugin.setPluginCategory(_HANDLE, 'Moje')
    polozky = store.oblubene_zoznam()
    if not polozky:
        _polozka('(prázdne — pridaj cez kontextové menu „Pridať do Moje“)',
                 _link(action='root'), 'DefaultPlaylist.png')
        xbmcplugin.endOfDirectory(_HANDLE); return
    _render_zoznam(polozky, moje_view=True)


def fav_add(p):
    rok = p.get('rok', '')
    nazov = p.get('nazov', '')
    polozka = {
        'nazov': nazov + ((' (%s)' % rok) if rok else ''),
        'cisty_nazov': nazov, 'en_nazov': p.get('en', ''), 'rok': rok,
        'plagat': p.get('plagat', ''), 'fanart': p.get('fanart', ''),
        'popis': p.get('popis', ''), 'media_type': p.get('mtype', 'movie'),
        'tmdb_id': p.get('tmdb_id', ''), 'rating': '',
    }
    store.oblubene_pridaj(polozka)
    _notif('Pridané do „Moje“: ' + nazov)


def fav_del(kluc):
    store.oblubene_odstran(kluc)
    _notif('Odobraté z „Moje“')
    xbmc.executebuiltin('Container.Refresh')


def odporucane():
    seed = store.seed_odporucania()
    if not seed or not seed.get('tmdb_id'):
        xbmcplugin.setPluginCategory(_HANDLE, 'Odporúčané')
        _polozka('Najprv si niečo pozri alebo pridaj do „Moje“ — potom sem prídu odporúčania',
                 _link(action='root'), 'DefaultFavourites.png')
        xbmcplugin.endOfDirectory(_HANDLE); return
    dlg = xbmcgui.DialogProgressBG(); dlg.create('KodiPlay', 'Načítavam odporúčania…')
    polozky = trakt.odporucania(seed['tmdb_id'], seed.get('media_type') == 'tv')
    dlg.close()
    nazov = seed.get('cisty_nazov') or seed.get('nazov', '')
    xbmcplugin.setPluginCategory(_HANDLE, 'Pretože si pozeral: ' + nazov)
    _render_zoznam(polozky)


# ── Rozpozerané ───────────────────────────────────────────────────────────────

def rozpozerane():
    xbmcplugin.setPluginCategory(_HANDLE, 'Rozpozerané')
    xbmcplugin.setContent(_HANDLE, 'videos')
    polozky = store.zoznam()
    if not polozky:
        _polozka('(nič rozpozerané)', _link(action='root'), 'DefaultInProgressShows.png', folder=True)
        xbmcplugin.endOfDirectory(_HANDLE); return
    for it in polozky:
        pos, tot = it.get('position', 0), it.get('total', 0)
        pct = int(pos / tot * 100) if tot else 0
        li = xbmcgui.ListItem(label='[%d%%] %s' % (pct, it['nazov']))
        if it.get('plagat'):
            li.setArt({'poster': it['plagat'], 'thumb': it['plagat']})
        li.setInfo('video', {'title': it['nazov']})
        li.setProperty('IsPlayable', 'true')
        url = _link(action='prehrat', ident=it['ident'], nazov=it['nazov'],
                    sub=it.get('sub', ''), plagat=it.get('plagat', ''),
                    fanart=it.get('fanart', ''), tmdb_id=it.get('tmdb_id', ''),
                    mtype=it.get('media_type', ''), en=it.get('en', ''), rok=it.get('rok', ''),
                    resume=pos, total=tot)
        li.addContextMenuItems([
            ('Odstrániť z rozpozeraných',
             'RunPlugin(%s)' % _link(action='zabudni', ident=it['ident'])),
        ])
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(_HANDLE)


def zabudni(ident):
    store.odstran(ident)
    xbmc.executebuiltin('Container.Refresh')


# ── Sťahovanie ────────────────────────────────────────────────────────────────

def download(ident, nazov):
    folder = _s('download_folder') or 'special://home/downloads/'
    if not folder.endswith('/'):
        folder += '/'
    xbmcvfs.mkdirs(folder)
    subor = re.sub(r'[<>:"/\\|?*]', '_', nazov)[:150] + '.mkv'
    cesta = folder + subor

    _notif('Získavam odkaz na sťahovanie…')
    link = webshare.vip_link(ident)
    if not link:
        _notif('Nepodarilo sa získať odkaz', chyba=True); return

    import urllib.request
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Sťahujem: ' + nazov)
    try:
        with urllib.request.urlopen(link, timeout=30) as r:
            total = int(r.headers.get('Content-Length', 0))
            f = xbmcvfs.File(cesta, 'w')
            done = 0
            while True:
                if dlg.iscanceled():
                    break
                chunk = r.read(1024 * 512)
                if not chunk:
                    break
                f.write(bytearray(chunk))
                done += len(chunk)
                if total:
                    dlg.update(int(done / total * 100),
                               '%s\n%.0f / %.0f MB' % (nazov, done / 1048576, total / 1048576))
            f.close()
        dlg.close()
        if total and done >= total:
            _notif('Stiahnuté: ' + subor)
        elif done:
            _notif('Sťahovanie zrušené/nekompletné', chyba=True)
    except Exception as e:
        dlg.close()
        _notif('Chyba pri sťahovaní: %s' % e, chyba=True)


def over_prihlasenie():
    webshare._token_cache["value"] = None
    webshare._last_error["msg"] = None
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Overujem prihlásenie…')
    token = webshare._get_token()
    vip = webshare.over_vip(token) if token else False
    dlg.close()
    if vip:
        _notif('Prihlásenie OK — VIP aktívny')
    elif token:
        xbmcgui.Dialog().ok('KodiPlay', 'Prihlásený, ale účet [B]nemá VIP[/B].\n'
                            'Sťahovanie/prehrávanie funguje len s VIP.')
    else:
        chyba = webshare._last_error.get("msg") or 'skontroluj meno/heslo/token'
        xbmcgui.Dialog().ok('KodiPlay', 'Prihlásenie zlyhalo:\n[B]%s[/B]' % chyba)


def router(paramstring):
    p = dict(parse_qsl(paramstring))
    action = p.get('action')
    if action == 'menu_filmy':
        menu_filmy()
    elif action == 'menu_serialy':
        menu_serialy()
    elif action == 'tv':
        tv_kanaly()
    elif action == 'play_tv':
        play_tv(p.get('url'), p.get('nazov', ''))
    elif action == 'trakt':
        zoznam_trakt(p.get('kat'), int(p.get('page', 1) or 1))
    elif action == 'zanre':
        zanre(p.get('typ', 'movie'))
    elif action == 'zaner':
        zoznam_zaner(p.get('typ', 'movie'), p.get('slug', ''), int(p.get('page', 1) or 1))
    elif action == 'film':
        film(p.get('en', ''), p.get('rok', ''), p.get('nazov', ''), p.get('plagat', ''),
             p.get('fanart', ''), p.get('popis', ''), p.get('tmdb_id', ''))
    elif action == 'serial':
        serial(p.get('en', ''), p.get('rok', ''), p.get('nazov', ''), p.get('plagat', ''),
               p.get('fanart', ''), p.get('popis', ''), p.get('tmdb_id', ''))
    elif action == 'serial_seria':
        serial_seria(p.get('en', ''), p.get('rok', ''), p.get('nazov', ''),
                     p.get('plagat', ''), p.get('fanart', ''), p.get('popis', ''),
                     int(p.get('sezona', 0) or 0), p.get('tmdb_id', ''))
    elif action == 'epizoda':
        epizoda(p.get('en', ''), p.get('rok', ''), p.get('nazov', ''),
                p.get('plagat', ''), p.get('fanart', ''), p.get('popis', ''),
                int(p.get('sezona', 0) or 0), int(p.get('epizoda', 0) or 0), p.get('tmdb_id', ''))
    elif action == 'hladat':
        hladat()
    elif action == 'moje':
        moje()
    elif action == 'fav_add':
        fav_add(p)
    elif action == 'fav_del':
        fav_del(p.get('kluc', ''))
    elif action == 'odporucane':
        odporucane()
    elif action == 'rozpozerane':
        rozpozerane()
    elif action == 'prehrat':
        prehrat(p.get('ident'), p.get('nazov', ''), p.get('sub', ''), p.get('plagat', ''),
                int(p.get('resume', 0) or 0), int(p.get('total', 0) or 0),
                p.get('tmdb_id', ''), p.get('mtype', ''), p.get('en', ''), p.get('rok', ''),
                p.get('fanart', ''), p.get('dalsia', ''))
    elif action == 'prehrat_auto':
        prehrat_auto(p.get('en', ''), p.get('rok', ''), p.get('nazov', ''), p.get('plagat', ''),
                     p.get('fanart', ''), p.get('popis', ''), p.get('tmdb_id', ''),
                     int(p.get('sezona', 0) or 0), int(p.get('epizoda', 0) or 0))
    elif action == 'download':
        download(p.get('ident'), p.get('nazov', ''))
    elif action == 'zabudni':
        zabudni(p.get('ident'))
    elif action == 'test_login':
        over_prihlasenie()
    elif action == 'nastavenia':
        _ADDON.openSettings(); hlavne_menu()
    else:
        hlavne_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
