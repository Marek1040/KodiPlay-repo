"""Katalóg filmov/seriálov cez TMDB — populárne / trending / top / žánre / CZ-SK.

Pôvodne to ťahal Trakt.tv, ale Trakt nasadil na api.trakt.tv Cloudflare bot-ochranu,
ktorá blokuje programový prístup (403 Forbidden aj cez curl). TMDB tento blok nemá
a poskytuje všetko potrebné vrátane plagátov/popisov, takže je nezávislé a rýchlejšie
(zoznam príde jedným volaním, bez extra detailov na položku).

Názvy funkcií ostali rovnaké kvôli spätnej kompatibilite (default.py sa nemení).
Používa iba vstavané moduly (urllib).
"""
import json
import urllib.request

TMDB_API_KEY = "5eba3d51d36e1710cb48aeb47ec94643"
TMDB_BASE = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/w500"
IMG_BG = "https://image.tmdb.org/t/p/w1280"


def _get(path):
    sep = '&' if '?' in path else '?'
    url = "%s%s%sapi_key=%s&language=sk-SK" % (TMDB_BASE, path, sep, TMDB_API_KEY)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "KodiPlay/1.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _spracuj(data, je_tv, limit=20):
    out = []
    for d in (data or {}).get("results", [])[:limit]:
        nazov = d.get("name") if je_tv else d.get("title")
        orig = d.get("original_name") if je_tv else d.get("original_title")
        datum = d.get("first_air_date") if je_tv else d.get("release_date")
        rok = (datum or "")[:4]
        poster = d.get("poster_path")
        back = d.get("backdrop_path")
        va = d.get("vote_average") or 0
        out.append({
            "nazov": (nazov or orig or "") + ((" (%s)" % rok) if rok else ""),
            "cisty_nazov": nazov or orig or "",
            "en_nazov": orig or nazov or "",   # original_title = dobrý dopyt pre Webshare
            "rok": rok,
            "plagat": (IMG + poster) if poster else "",
            "fanart": (IMG_BG + back) if back else "",
            "rating": str(int(va * 10)) if va else "",
            "popis": d.get("overview", "") or "",
            "media_type": "tv" if je_tv else "movie",
        })
    return out


def _zoznam(path, je_tv=False, limit=20):
    return _spracuj(_get(path), je_tv, limit)


# Žánre: slug → SK názov (slug ostáva rovnaký kvôli default.py); TMDB id-čka nižšie.
ZANRE = [
    ("action", "Akčné"), ("adventure", "Dobrodružné"), ("animation", "Animované"),
    ("comedy", "Komédie"), ("crime", "Krimi"), ("documentary", "Dokumentárne"),
    ("drama", "Drámy"), ("fantasy", "Fantasy"), ("horror", "Horory"),
    ("mystery", "Mysteriózne"), ("romance", "Romantické"),
    ("science-fiction", "Sci-Fi"), ("thriller", "Trilery"),
]

# slug → (TMDB movie genre id, TMDB tv genre id) — TV nemá všetky žánre, mapujem najbližší
_GENRE_IDS = {
    "action": (28, 10759), "adventure": (12, 10759), "animation": (16, 16),
    "comedy": (35, 35), "crime": (80, 80), "documentary": (99, 99),
    "drama": (18, 18), "fantasy": (14, 10765), "horror": (27, 9648),
    "mystery": (9648, 9648), "romance": (10749, 18),
    "science-fiction": (878, 10765), "thriller": (53, 80),
}


def popularne_filmy():
    return _zoznam("/movie/popular")

def trending_filmy():
    return _zoznam("/trending/movie/week")

def anticipovane_filmy():
    return _zoznam("/movie/upcoming")

def top_filmy():
    return _zoznam("/movie/top_rated")

def popularne_serialy():
    return _zoznam("/tv/popular", je_tv=True)

def trending_serialy():
    return _zoznam("/trending/tv/week", je_tv=True)

def anticipovane_serialy():
    return _zoznam("/tv/on_the_air", je_tv=True)

def top_serialy():
    return _zoznam("/tv/top_rated", je_tv=True)

def filmy_zaner(slug):
    gid = _GENRE_IDS.get(slug, (None, None))[0]
    return _zoznam("/discover/movie?with_genres=%s&sort_by=popularity.desc" % gid)

def serialy_zaner(slug):
    gid = _GENRE_IDS.get(slug, (None, None))[1]
    return _zoznam("/discover/tv?with_genres=%s&sort_by=popularity.desc" % gid, je_tv=True)

def cz_sk_filmy():
    return _zoznam("/discover/movie?with_original_language=cs|sk&sort_by=popularity.desc")

def cz_sk_serialy():
    return _zoznam("/discover/tv?with_original_language=cs|sk&sort_by=popularity.desc", je_tv=True)
