"""Webshare.cz API pre Kodi addon — login, vyhľadávanie, VIP link, skórovanie.

Používa iba vstavané moduly (urllib) — žiadna závislosť na script.module.requests.
Nastavenia sa čítajú z addon settings (xbmcaddon).
"""
import hashlib
import re
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET

import xbmcaddon

from resources.lib.md5crypt import md5crypt

BASE_URL = "https://webshare.cz/api/"
_ADDON = xbmcaddon.Addon()
_token_cache = {"value": None}
_last_error = {"msg": None}  # posledná chyba prihlásenia (pre diagnostiku)


def _s(key, default=""):
    try:
        return _ADDON.getSetting(key) or default
    except Exception:
        return default


def _post(endpoint, data, timeout=15):
    """POST form-urlencoded, vráti bytes (obsah odpovede) alebo None."""
    try:
        body = urllib.parse.urlencode(data).encode("utf-8")
        req = urllib.request.Request(
            BASE_URL + endpoint, data=body,
            headers={
                "Accept": "text/xml; charset=UTF-8",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "User-Agent": "KodiPlay/1.0",
            })
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except Exception:
        return None


def _get_token():
    if _token_cache["value"]:
        return _token_cache["value"]
    username = _s("ws_username").strip()
    password = _s("ws_password").strip()  # Kodi klávesnica občas pridá medzeru
    if username and password:
        tok = login(username, password)
        if tok:
            _token_cache["value"] = tok
            return tok
    manual = _s("ws_token").strip()
    if manual:
        _token_cache["value"] = manual
    return _token_cache["value"]


def _sprava(root, fallback):
    m = root.find("message")
    return m.text if m is not None and m.text else fallback


def login(username, password):
    """Salt → md5_crypt → sha1 → digest → token. Vráti token alebo None.
    Chybu zapíše do _last_error['msg'] pre diagnostiku."""
    _last_error["msg"] = None
    obsah = _post("salt/", {"username_or_email": username})
    if not obsah:
        _last_error["msg"] = "Bez odpovede zo salt/ (sieť/blokovanie?)"
        return None
    try:
        root = ET.fromstring(obsah)
        salt_el = root.find("salt")
        if salt_el is None or not salt_el.text:
            _last_error["msg"] = _sprava(root, "Neznáme meno/email (salt sa nevrátil)")
            return None
        salt = salt_el.text
        md5 = md5crypt(password.encode("utf-8"), salt.encode("utf-8"))
        password_digest = hashlib.sha1(md5).hexdigest()
        digest = hashlib.md5(
            (username + ":Webshare:" + password_digest).encode("utf-8")
        ).hexdigest()
        obsah = _post("login/", {
            "username_or_email": username,
            "password": password_digest,
            "digest": digest,
            "keep_logged_in": 1,
        })
        if not obsah:
            _last_error["msg"] = "Bez odpovede z login/"
            return None
        root = ET.fromstring(obsah)
        status = root.find("status")
        if status is not None and status.text == "OK":
            t = root.find("token")
            if t is not None:
                return t.text
        _last_error["msg"] = _sprava(root, "Prihlásenie odmietnuté (heslo?)")
    except Exception as e:
        _last_error["msg"] = "Chyba: %s" % e
    return None


# ── Skórovanie ────────────────────────────────────────────────────────────────

def _analyza(nazov, velkost_gb, dlzka_minuty, rychlost_netu):
    text = nazov.lower()

    jazyk, jazyk_score = "EN / Iny", 15
    if "cz" in text or "czech" in text:
        jazyk, jazyk_score = "CZ", 100
    elif "sk" in text or "slovak" in text:
        jazyk, jazyk_score = "SK", 100
    elif "dabing" in text:
        jazyk, jazyk_score = "CZ", 100

    kvalita, kvalita_score, je_4k = "SD", 0, False
    if "2160p" in text or "4k" in text or "uhd" in text:
        kvalita, kvalita_score, je_4k = "4K", 100, True
    elif "1080p" in text or "fhd" in text:
        kvalita, kvalita_score = "1080p", 50
    elif "720p" in text or "hd" in text:
        kvalita, kvalita_score = "720p", 20

    if "hevc" in text or "h265" in text or "x265" in text:
        kodek = "HEVC"
    elif "h264" in text or "x264" in text or "avc" in text:
        kodek = "H.264"
    else:
        kodek = ""

    bitrate = (velkost_gb * 1024 * 1024 * 1024 * 8) / max(1, dlzka_minuty * 60) / (1024 * 1024)
    plynuly = rychlost_netu >= bitrate * 1.5

    score = jazyk_score + kvalita_score
    if kvalita == "1080p" and velkost_gb < 4.0:
        score -= 30
    if je_4k and kodek == "HEVC":
        score -= 15

    return {"jazyk": jazyk, "kvalita": kvalita, "kodek": kodek,
            "velkost_gb": velkost_gb, "plynuly": plynuly,
            "bitrate": round(bitrate, 1),
            "score": score if plynuly else 0}


def _text(el, tag, default=""):
    n = el.find(tag)
    return n.text if n is not None and n.text else default


EPISODE_PATTERNS = [(r'[Ss](\d+)[Ee](\d+)', 2), (r'(\d+)[xX](\d+)', 2), (r'[Ee]p?\s*(\d+)', 1)]

def detect_episode(nazov):
    for pattern, groups in EPISODE_PATTERNS:
        m = re.search(pattern, nazov)
        if m:
            return (int(m.group(1)), int(m.group(2))) if groups == 2 else (1, int(m.group(1)))
    return None, None


def vyhladaj(query):
    token = _get_token()
    if not token:
        return []
    try:
        speed = int(_s("speed_mbps", "50") or 50)
    except ValueError:
        speed = 50
    obsah = _post("search/", {
        "wst": token, "offset": "0", "limit": "25",
        "category": "video", "sort": "rating", "what": query, "maybe_removed": "1"
    })
    if not obsah:
        return []
    try:
        root = ET.fromstring(obsah)
        zakazane = ('sample', 'trailer', 'teaser')
        out = []
        for f in root.findall(".//file"):
            nazov = (f.find("name").text or "")
            if any(z in nazov.lower() for z in zakazane):
                continue
            velkost_gb = int(f.find("size").text) / (1024 ** 3)
            ident = f.find("ident").text
            a = _analyza(nazov, velkost_gb, 120, speed)
            if a["score"] <= 0:
                continue
            sez, ep = detect_episode(nazov)
            try:
                plus = int(_text(f, "positive_votes", "0") or 0)
                minus = int(_text(f, "negative_votes", "0") or 0)
            except ValueError:
                plus = minus = 0
            out.append({"nazov": nazov, "ident": ident, "analyza": a,
                        "sezona": sez, "epizoda": ep,
                        "plus": plus, "minus": minus,
                        "nahlad": _text(f, "img"),
                        "chraneny": _text(f, "password") == "1"})
        out.sort(key=lambda x: x["analyza"]["score"], reverse=True)
        return out
    except Exception:
        return []


def over_vip(token=None):
    """Overí platnosť tokenu + VIP cez /user_data/. Vráti True ak VIP."""
    token = token or _get_token()
    if not token:
        return False
    obsah = _post("user_data/", {"wst": token})
    if not obsah:
        return False
    try:
        root = ET.fromstring(obsah)
        if root.find("status") is not None and root.find("status").text == "OK":
            vip = root.find("vip")
            return vip is not None and vip.text == "1"
    except Exception:
        pass
    return False


def vip_link(ident):
    token = _get_token()
    if not token:
        return None
    obsah = _post("file_link/", {"wst": token, "ident": ident, "force_https": "1"})
    if not obsah:
        return None
    try:
        root = ET.fromstring(obsah)
        if root.find("status").text == "OK":
            return root.find("link").text
    except Exception:
        pass
    return None
