"""KodiPlay service — sleduje prehrávanie a ukladá pozíciu (rozpozerané).

Číta window properties nastavené pri spustení (KodiPlay.ident/nazov/plagat/sub)
a priebežne + pri zastavení ukladá pozíciu do watched.json.
"""
import xbmc
import xbmcgui

from resources.lib import store

WIN = xbmcgui.Window(10000)


class Prehravac(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.aktivny = None

    def _zisti_kontext(self):
        ident = WIN.getProperty('KodiPlay.ident')
        if ident:
            self.aktivny = {
                'ident': ident,
                'nazov': WIN.getProperty('KodiPlay.nazov'),
                'plagat': WIN.getProperty('KodiPlay.plagat'),
                'sub': WIN.getProperty('KodiPlay.sub'),
            }
            WIN.clearProperty('KodiPlay.ident')  # aby to nededilo ďalšie prehrávanie
        else:
            self.aktivny = None

    def onAVStarted(self):
        self._zisti_kontext()

    def onPlayBackStarted(self):
        if self.aktivny is None:
            self._zisti_kontext()

    def uloz_poziciu(self):
        if not self.aktivny:
            return
        try:
            pos = self.getTime()
            total = self.getTotalTime()
        except Exception:
            return
        if total > 0:
            store.uloz(self.aktivny['ident'], self.aktivny['nazov'],
                       self.aktivny['plagat'], self.aktivny['sub'], pos, total)

    def onPlayBackStopped(self):
        self.aktivny = None

    def onPlayBackEnded(self):
        if self.aktivny:
            store.uloz(self.aktivny['ident'], self.aktivny['nazov'],
                       self.aktivny['plagat'], self.aktivny['sub'], 999999, 1000000)  # dopozerané
        self.aktivny = None


monitor = xbmc.Monitor()
player = Prehravac()

while not monitor.abortRequested():
    try:
        if player.isPlayingVideo() and player.aktivny:
            player.uloz_poziciu()
    except Exception:
        pass
    if monitor.waitForAbort(15):
        break
