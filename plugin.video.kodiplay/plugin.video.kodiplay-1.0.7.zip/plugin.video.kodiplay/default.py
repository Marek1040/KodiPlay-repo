"""KodiPlay — Kodi addon. Webshare.cz vyhľadávanie a prehrávanie priamo v Kodi.

Menu: Filmy / Seriály / TV / Hľadať / Rozpozerané / Nastavenia.
Filmy a Seriály majú podmenu (Populárne / Trending / Očakávané).
"""
import sys
import re
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from resources.lib import webshare
from resources.lib import tmdb
from resources.lib import trakt
from resources.lib import opensubtitles
from resources.lib import tv
from resources.lib import store

_HANDLE = int(sys.argv[1])
_URL = sys.argv[0]
_ADDON = xbmcaddon.Addon()
_WIN = xbmcgui.Window(10000)


def _link(**kwargs):
    return _URL + '?' + urlencode(kwargs)


def _s(key, default=''):
    try:
        return _ADDON.getSetting(key) or default
    except Exception:
        return default


def _notif(sprava, chyba=False, cas=4000):
    xbmcgui.Dialog().notification('KodiPlay', sprava,
                                  xbmcgui.NOTIFICATION_ERROR if chyba else xbmcgui.NOTIFICATION_INFO, cas)


def _polozka(nazov, url, ikona, folder=True):
    li = xbmcgui.ListItem(label=nazov)
    li.setArt({'icon': ikona, 'thumb': ikona})
    xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=folder)


# ── Hlavné menu ───────────────────────────────────────────────────────────────

def hlavne_menu():
    xbmcplugin.setPluginCategory(_HANDLE, 'KodiPlay')
    xbmcplugin.setContent(_HANDLE, 'videos')
    _polozka('Filmy',        _link(action='menu_filmy'),   'DefaultMovies.png')
    _polozka('Seriály',      _link(action='menu_serialy'), 'DefaultTVShows.png')
    _polozka('TV',           _link(action='tv'),           'DefaultAddonPVRClient.png')
    _polozka('Hľadať',       _link(action='hladat'),       'DefaultAddonsSearch.png')
    _polozka('Rozpozerané',  _link(action='rozpozerane'),  'DefaultInProgressShows.png')
    _polozka('Nastavenia',   _link(action='nastavenia'),   'DefaultAddonService.png')
    xbmcplugin.endOfDirectory(_HANDLE)


def menu_filmy():
    xbmcplugin.setPluginCategory(_HANDLE, 'Filmy')
    _polozka('Populárne',   _link(action='trakt', kat='pop_movie'),   'DefaultMovies.png')
    _polozka('Trending',    _link(action='trakt', kat='trend_movie'), 'DefaultMovies.png')
    _polozka('Top 20',      _link(action='trakt', kat='top_movie'),   'DefaultMovies.png')
    _polozka('Očakávané',   _link(action='trakt', kat='antic_movie'), 'DefaultMovies.png')
    _polozka('CZ / SK',     _link(action='trakt', kat='cz_movie'),    'DefaultMovies.png')
    _polozka('Žánre',       _link(action='zanre', typ='movie'),       'DefaultGenre.png')
    xbmcplugin.endOfDirectory(_HANDLE)


def menu_serialy():
    xbmcplugin.setPluginCategory(_HANDLE, 'Seriály')
    _polozka('Populárne', _link(action='trakt', kat='pop_tv'),   'DefaultTVShows.png')
    _polozka('Trending',  _link(action='trakt', kat='trend_tv'), 'DefaultTVShows.png')
    _polozka('Top 20',    _link(action='trakt', kat='top_tv'),   'DefaultTVShows.png')
    _polozka('Očakávané', _link(action='trakt', kat='antic_tv'), 'DefaultTVShows.png')
    _polozka('CZ / SK',   _link(action='trakt', kat='cz_tv'),    'DefaultTVShows.png')
    _polozka('Žánre',     _link(action='zanre', typ='tv'),       'DefaultGenre.png')
    xbmcplugin.endOfDirectory(_HANDLE)


def zanre(typ):
    xbmcplugin.setPluginCategory(_HANDLE, 'Žánre')
    ikona = 'DefaultTVShows.png' if typ == 'tv' else 'DefaultMovies.png'
    for slug, nazov in trakt.ZANRE:
        _polozka(nazov, _link(action='zaner', typ=typ, slug=slug), ikona)
    xbmcplugin.endOfDirectory(_HANDLE)


# ── TV kanály ─────────────────────────────────────────────────────────────────

def tv_kanaly():
    xbmcplugin.setPluginCategory(_HANDLE, 'TV')
    xbmcplugin.setContent(_HANDLE, 'videos')
    for ch in tv.kanaly():
        li = xbmcgui.ListItem(label=ch['nazov'])
        if ch.get('logo'):
            li.setArt({'icon': ch['logo'], 'thumb': ch['logo']})
        li.setInfo('video', {'title': ch['nazov']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(_HANDLE, _link(action='play_tv', url=ch['url'], nazov=ch['nazov']), li, isFolder=False)
    xbmcplugin.endOfDirectory(_HANDLE)


def play_tv(url, nazov):
    li = xbmcgui.ListItem(path=url)
    li.setInfo('video', {'title': nazov})
    xbmcplugin.setResolvedUrl(_HANDLE, True, li)


# ── Trakt zoznamy ─────────────────────────────────────────────────────────────

def _render_zoznam(polozky):
    xbmcplugin.setContent(_HANDLE, 'movies')
    for m in polozky:
        li = xbmcgui.ListItem(label=m['nazov'])
        li.setArt({'poster': m['plagat'], 'thumb': m['plagat'],
                   'fanart': m.get('fanart') or m['plagat']})
        li.setInfo('video', {'title': m['cisty_nazov'], 'plot': m.get('popis', ''),
                             'year': int(m['rok']) if m['rok'].isdigit() else 0,
                             'mediatype': 'tvshow' if m['media_type'] == 'tv' else 'movie'})
        url = _link(action='film', en=m['en_nazov'], rok=m['rok'], nazov=m['cisty_nazov'],
                    plagat=m['plagat'], fanart=m.get('fanart', ''), popis=m.get('popis', ''))
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=True)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_HANDLE)


def zoznam_trakt(kat):
    mapa = {
        'pop_movie':   trakt.popularne_filmy,   'trend_movie': trakt.trending_filmy,
        'antic_movie': trakt.anticipovane_filmy, 'top_movie':  trakt.top_filmy,
        'cz_movie':    trakt.cz_sk_filmy,
        'pop_tv':      trakt.popularne_serialy,  'trend_tv':   trakt.trending_serialy,
        'antic_tv':    trakt.anticipovane_serialy, 'top_tv':   trakt.top_serialy,
        'cz_tv':       trakt.cz_sk_serialy,
    }
    fn = mapa.get(kat)
    if not fn:
        hlavne_menu(); return
    dlg = xbmcgui.DialogProgressBG(); dlg.create('KodiPlay', 'Načítavam z Trakt.tv…')
    polozky = fn()
    dlg.close()
    _render_zoznam(polozky)


def zoznam_zaner(typ, slug):
    dlg = xbmcgui.DialogProgressBG(); dlg.create('KodiPlay', 'Načítavam žáner…')
    polozky = trakt.serialy_zaner(slug) if typ == 'tv' else trakt.filmy_zaner(slug)
    dlg.close()
    _render_zoznam(polozky)


# ── Vyhľadávanie / streamy ────────────────────────────────────────────────────

def hladat():
    kb = xbmc.Keyboard('', 'Zadaj názov filmu alebo seriálu')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(_HANDLE); return
    dopyt = kb.getText().strip()
    d = tmdb.preloz_nazov(dopyt)
    dopyty = []
    if d['en']:
        dopyty += [(d['en'] + ' ' + d['rok']).strip(), d['en']]
    if d['cz'] and d['cz'].lower() != d['en'].lower():
        dopyty += [(d['cz'] + ' ' + d['rok']).strip()]
    if not dopyty:
        dopyty = [dopyt]
    _streamy(dopyty, cisty=d['cisty'] or dopyt, rok=d['rok'],
             plagat=d['plagat'], fanart=d['fanart'], popis=d['popis'])


def film(en, rok, nazov, plagat, fanart, popis):
    _streamy([(en + ' ' + rok).strip(), en], cisty=nazov, rok=rok,
             plagat=plagat, fanart=fanart, popis=popis)


def _streamy(dopyty, cisty, rok, plagat, fanart, popis):
    xbmcplugin.setPluginCategory(_HANDLE, 'Streamy: ' + cisty)
    xbmcplugin.setContent(_HANDLE, 'videos')

    seen, vysledky = set(), []
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Hľadám na Webshare…')
    for i, q in enumerate(dopyty):
        if dlg.iscanceled():
            break
        dlg.update(int(i / max(1, len(dopyty)) * 100), q)
        for s in webshare.vyhladaj(q):
            if s['ident'] not in seen:
                seen.add(s['ident']); vysledky.append(s)
    dlg.close()

    if not vysledky:
        _notif('Nič sa nenašlo (over prihlásenie v Nastaveniach)', chyba=True)
        xbmcplugin.endOfDirectory(_HANDLE); return

    sub_query = (cisty + ' ' + rok).strip()
    for s in vysledky:
        a = s['analyza']
        znacky = []
        if s['sezona'] and s['epizoda']:
            znacky.append('S%02dE%02d' % (s['sezona'], s['epizoda']))
        znacky += [a['jazyk'], a['kvalita']]
        if a['kodek']:
            znacky.append(a['kodek'])
        znacky.append('%.1f GB' % a['velkost_gb'])
        plynulost = 'Plynulé ✓' if a.get('plynuly') else 'Môže sekať ⚠'
        znacky.append(plynulost.split()[0])
        li = xbmcgui.ListItem(label='[%s] %s' % (' · '.join(znacky), s['nazov']))
        nahlad = s.get('nahlad') or plagat
        li.setArt({'poster': plagat, 'thumb': nahlad, 'icon': nahlad,
                   'fanart': fanart or plagat})
        # Popis streamu (detaily súboru) + popis filmu
        hlasy = ''
        if s.get('plus') or s.get('minus'):
            hlasy = '  (👍 %d / 👎 %d)' % (s.get('plus', 0), s.get('minus', 0))
        detaily = [
            'Súbor: %s' % s['nazov'],
            'Jazyk: %s' % a['jazyk'],
            'Kvalita: %s%s' % (a['kvalita'], ' · ' + a['kodek'] if a['kodek'] else ''),
            'Veľkosť: %.1f GB   Bitrate: ~%.1f Mb/s' % (a['velkost_gb'], a.get('bitrate', 0)),
            'Prehrávanie: %s%s' % (plynulost, hlasy),
        ]
        if s.get('chraneny'):
            detaily.append('⚠ Súbor chránený heslom')
        if s['sezona'] and s['epizoda']:
            detaily.insert(0, 'Epizóda: S%02dE%02d' % (s['sezona'], s['epizoda']))
        plot = '[B]Stream[/B]\n' + '\n'.join(detaily)
        if popis:
            plot += '\n\n[B]Popis[/B]\n' + popis
        li.setInfo('video', {'title': '[%s · %s] %s' % (a['jazyk'], a['kvalita'], cisty),
                             'plot': plot,
                             'year': int(rok) if rok.isdigit() else 0})
        li.setProperty('IsPlayable', 'true')
        url = _link(action='prehrat', ident=s['ident'], nazov=s['nazov'],
                    sub=sub_query, plagat=plagat)
        li.addContextMenuItems([
            ('Stiahnuť do zariadenia',
             'RunPlugin(%s)' % _link(action='download', ident=s['ident'], nazov=s['nazov'])),
        ])
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=False)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_HANDLE)


def prehrat(ident, nazov, sub='', plagat='', resume=0, total=0):
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Získavam odkaz…')
    link = webshare.vip_link(ident)
    dlg.close()
    if not link:
        _notif('Nepodarilo sa získať odkaz (VIP/token?)', chyba=True)
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem()); return

    # Kontext pre service (rozpozerané)
    _WIN.setProperty('KodiPlay.ident', ident)
    _WIN.setProperty('KodiPlay.nazov', nazov)
    _WIN.setProperty('KodiPlay.plagat', plagat)
    _WIN.setProperty('KodiPlay.sub', sub)

    li = xbmcgui.ListItem(path=link)
    li.setInfo('video', {'title': nazov})
    if plagat:
        li.setArt({'poster': plagat, 'thumb': plagat})
    if resume and total:
        li.setProperty('ResumeTime', str(resume))
        li.setProperty('TotalTime', str(total))
    # Titulky cez OpenSubtitles
    if sub and opensubtitles.je_nakonfigurovany():
        try:
            linky = opensubtitles.linky_pre(sub, max_pocet=3)
            if linky:
                li.setSubtitles(linky)
        except Exception:
            pass
    xbmcplugin.setResolvedUrl(_HANDLE, True, li)


# ── Rozpozerané ───────────────────────────────────────────────────────────────

def rozpozerane():
    xbmcplugin.setPluginCategory(_HANDLE, 'Rozpozerané')
    xbmcplugin.setContent(_HANDLE, 'videos')
    polozky = store.zoznam()
    if not polozky:
        _polozka('(nič rozpozerané)', _link(action='root'), 'DefaultInProgressShows.png', folder=True)
        xbmcplugin.endOfDirectory(_HANDLE); return
    for it in polozky:
        pos, tot = it.get('position', 0), it.get('total', 0)
        pct = int(pos / tot * 100) if tot else 0
        li = xbmcgui.ListItem(label='[%d%%] %s' % (pct, it['nazov']))
        if it.get('plagat'):
            li.setArt({'poster': it['plagat'], 'thumb': it['plagat']})
        li.setInfo('video', {'title': it['nazov']})
        li.setProperty('IsPlayable', 'true')
        url = _link(action='prehrat', ident=it['ident'], nazov=it['nazov'],
                    sub=it.get('sub', ''), plagat=it.get('plagat', ''),
                    resume=pos, total=tot)
        li.addContextMenuItems([
            ('Odstrániť z rozpozeraných',
             'RunPlugin(%s)' % _link(action='zabudni', ident=it['ident'])),
        ])
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(_HANDLE)


def zabudni(ident):
    store.odstran(ident)
    xbmc.executebuiltin('Container.Refresh')


# ── Sťahovanie ────────────────────────────────────────────────────────────────

def download(ident, nazov):
    folder = _s('download_folder') or 'special://home/downloads/'
    if not folder.endswith('/'):
        folder += '/'
    xbmcvfs.mkdirs(folder)
    subor = re.sub(r'[<>:"/\\|?*]', '_', nazov)[:150] + '.mkv'
    cesta = folder + subor

    _notif('Získavam odkaz na sťahovanie…')
    link = webshare.vip_link(ident)
    if not link:
        _notif('Nepodarilo sa získať odkaz', chyba=True); return

    import urllib.request
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Sťahujem: ' + nazov)
    try:
        with urllib.request.urlopen(link, timeout=30) as r:
            total = int(r.headers.get('Content-Length', 0))
            f = xbmcvfs.File(cesta, 'w')
            done = 0
            while True:
                if dlg.iscanceled():
                    break
                chunk = r.read(1024 * 512)
                if not chunk:
                    break
                f.write(bytearray(chunk))
                done += len(chunk)
                if total:
                    dlg.update(int(done / total * 100),
                               '%s\n%.0f / %.0f MB' % (nazov, done / 1048576, total / 1048576))
            f.close()
        dlg.close()
        if total and done >= total:
            _notif('Stiahnuté: ' + subor)
        elif done:
            _notif('Sťahovanie zrušené/nekompletné', chyba=True)
    except Exception as e:
        dlg.close()
        _notif('Chyba pri sťahovaní: %s' % e, chyba=True)


def over_prihlasenie():
    webshare._token_cache["value"] = None
    dlg = xbmcgui.DialogProgress(); dlg.create('KodiPlay', 'Overujem prihlásenie…')
    token = webshare._get_token()
    vip = webshare.over_vip(token) if token else False
    dlg.close()
    if vip:
        _notif('Prihlásenie OK — VIP aktívny')
    elif token:
        _notif('Prihlásený, ale BEZ VIP', chyba=True)
    else:
        _notif('Prihlásenie zlyhalo — skontroluj meno/heslo/token', chyba=True)


def router(paramstring):
    p = dict(parse_qsl(paramstring))
    action = p.get('action')
    if action == 'menu_filmy':
        menu_filmy()
    elif action == 'menu_serialy':
        menu_serialy()
    elif action == 'tv':
        tv_kanaly()
    elif action == 'play_tv':
        play_tv(p.get('url'), p.get('nazov', ''))
    elif action == 'trakt':
        zoznam_trakt(p.get('kat'))
    elif action == 'zanre':
        zanre(p.get('typ', 'movie'))
    elif action == 'zaner':
        zoznam_zaner(p.get('typ', 'movie'), p.get('slug', ''))
    elif action == 'film':
        film(p.get('en', ''), p.get('rok', ''), p.get('nazov', ''),
             p.get('plagat', ''), p.get('fanart', ''), p.get('popis', ''))
    elif action == 'hladat':
        hladat()
    elif action == 'rozpozerane':
        rozpozerane()
    elif action == 'prehrat':
        prehrat(p.get('ident'), p.get('nazov', ''), p.get('sub', ''), p.get('plagat', ''),
                int(p.get('resume', 0) or 0), int(p.get('total', 0) or 0))
    elif action == 'download':
        download(p.get('ident'), p.get('nazov', ''))
    elif action == 'zabudni':
        zabudni(p.get('ident'))
    elif action == 'test_login':
        over_prihlasenie()
    elif action == 'nastavenia':
        _ADDON.openSettings(); hlavne_menu()
    else:
        hlavne_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
