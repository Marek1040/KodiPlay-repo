"""Unix MD5-crypt — potrebné pre Webshare login (SHA1(MD5_CRYPT(heslo, salt))).

Kompaktná, samostatná implementácia (Kodi nemá passlib).
"""
import hashlib

ITOA64 = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
MAGIC = b'$1$'


def _to64(v, n):
    out = b''
    while n > 0:
        out += ITOA64[v & 0x3f].encode('ascii')
        v >>= 6
        n -= 1
    return out


def md5crypt(password, salt, magic=MAGIC):
    """password, salt, magic ako bytes. Vráti reťazec $1$salt$hash (bytes)."""
    if isinstance(password, str):
        password = password.encode('utf-8')
    if isinstance(salt, str):
        salt = salt.encode('utf-8')
    # salt max 8 znakov, bez prípadného $
    salt = salt.split(b'$')[0][:8]

    m = hashlib.md5()
    m.update(password + magic + salt)

    m2 = hashlib.md5()
    m2.update(password + salt + password)
    final = m2.digest()

    pl = len(password)
    while pl > 0:
        m.update(final[:min(16, pl)])
        pl -= 16

    i = len(password)
    while i:
        if i & 1:
            m.update(b'\x00')
        else:
            m.update(password[:1])
        i >>= 1
    final = m.digest()

    for i in range(1000):
        m3 = hashlib.md5()
        if i & 1:
            m3.update(password)
        else:
            m3.update(final)
        if i % 3:
            m3.update(salt)
        if i % 7:
            m3.update(password)
        if i & 1:
            m3.update(final)
        else:
            m3.update(password)
        final = m3.digest()

    out = b''
    out += _to64((final[0] << 16) | (final[6] << 8) | final[12], 4)
    out += _to64((final[1] << 16) | (final[7] << 8) | final[13], 4)
    out += _to64((final[2] << 16) | (final[8] << 8) | final[14], 4)
    out += _to64((final[3] << 16) | (final[9] << 8) | final[15], 4)
    out += _to64((final[4] << 16) | (final[10] << 8) | final[5], 4)
    out += _to64(final[11], 2)

    return magic + salt + b'$' + out
