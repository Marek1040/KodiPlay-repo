"""Free / testovacie live TV kanály (verejné HLS streamy) — rovnaké ako web appka."""

KANALY = [
    {"nazov": "Red Bull TV",
     "url": "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8",
     "logo": "https://i.imgur.com/2K8lFqK.png"},
    {"nazov": "DW English",
     "url": "https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8",
     "logo": ""},
    {"nazov": "NASA TV",
     "url": "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8",
     "logo": ""},
    {"nazov": "Akamai Live (test)",
     "url": "https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8", "logo": ""},
    {"nazov": "Big Buck Bunny (test)",
     "url": "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", "logo": ""},
    {"nazov": "Apple HLS (test)",
     "url": "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_ts/master.m3u8",
     "logo": ""},
    {"nazov": "Tears of Steel (test)",
     "url": "https://test-streams.mux.dev/tos_ismc/main.m3u8", "logo": ""},
]


def kanaly():
    return KANALY
