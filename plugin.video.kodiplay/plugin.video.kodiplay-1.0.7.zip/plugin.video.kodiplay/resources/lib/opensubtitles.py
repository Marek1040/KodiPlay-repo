"""OpenSubtitles.com — titulky pre Kodi addon (urllib, žiadna závislosť).

Nastavenia v addone: os_api_key, os_username, os_password, os_langs (napr. "cs,sk").
Vráti priame .srt download linky, ktoré sa cez ListItem.setSubtitles pripoja k prehrávaniu.
"""
import json
import urllib.request
import urllib.parse

import xbmcaddon

BASE = "https://api.opensubtitles.com/api/v1"
UA = "KodiPlay v1.0"
_ADDON = xbmcaddon.Addon()
_token = {"value": None}


def _s(key, default=""):
    try:
        return _ADDON.getSetting(key) or default
    except Exception:
        return default


def je_nakonfigurovany():
    return bool(_s("os_api_key").strip())


def _req(path, method="GET", token=None, telo=None, params=None):
    url = BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = {
        "Api-Key": _s("os_api_key").strip(),
        "User-Agent": UA,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(telo).encode("utf-8") if telo is not None else None
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _login():
    if _token["value"]:
        return _token["value"]
    u, p = _s("os_username").strip(), _s("os_password")
    if not u or not p:
        return None
    res = _req("/login", method="POST", telo={"username": u, "password": p})
    if res and res.get("token"):
        _token["value"] = res["token"]
    return _token["value"]


def hladaj(query, langs=None):
    """Vráti zoznam titulkov [{file_id, language, release}] pre textový dopyt."""
    if not je_nakonfigurovany() or not query:
        return []
    langs = langs or _s("os_langs", "cs,sk")
    data = _req("/subtitles", params={
        "query": query, "languages": langs,
        "order_by": "download_count", "order_direction": "desc",
    })
    if not data:
        return []
    out = []
    for it in data.get("data", []):
        attr = it.get("attributes", {})
        files = attr.get("files", [])
        if files:
            out.append({"file_id": files[0].get("file_id"),
                        "language": attr.get("language", ""),
                        "release": attr.get("release", "")})
    return out


def ziskaj_link(file_id):
    """Vráti priamy .srt link (počíta sa do denného limitu)."""
    token = _login()
    if not token:
        return None
    res = _req("/download", method="POST", token=token, telo={"file_id": file_id})
    return res.get("link") if res else None


def linky_pre(query, max_pocet=3):
    """Nájde a stiahne až N titulkových linkov pre dopyt — pripravené pre setSubtitles."""
    if not je_nakonfigurovany():
        return []
    out = []
    for t in hladaj(query)[:max_pocet]:
        link = ziskaj_link(t["file_id"])
        if link:
            out.append(link)
    return out
