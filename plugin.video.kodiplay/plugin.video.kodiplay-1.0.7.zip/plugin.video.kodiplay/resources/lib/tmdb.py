"""TMDB — preloží SK/CZ názov na originálny (anglický) pre lepšie Webshare výsledky.

Používa iba vstavané moduly (urllib) — žiadna závislosť.
"""
import re
import json
import urllib.request
import urllib.parse

API_KEY = "5eba3d51d36e1710cb48aeb47ec94643"


def _get(url, params, timeout=6):
    try:
        full = url + "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(full, headers={"User-Agent": "KodiPlay/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return {}


def preloz_nazov(query):
    """Vráti dict {en, rok, cz, cisty, plagat, fanart, popis}. Prázdne polia ak sa nič nenájde."""
    prazdne = {"en": query, "rok": "", "cz": "", "cisty": query,
               "plagat": "", "fanart": "", "popis": ""}
    year_m = re.search(r'\b(19|20)\d{2}\b', query)
    year = year_m.group() if year_m else None
    clean = re.sub(r'\b(19|20)\d{2}\b', '', query).strip() if year else query

    najlepsi = None
    for endpoint in ("movie", "tv"):
        params = {"api_key": API_KEY, "query": clean, "language": "sk-SK", "page": 1}
        if year:
            params["year" if endpoint == "movie" else "first_air_date_year"] = year
        data = _get("https://api.themoviedb.org/3/search/" + endpoint, params)
        vysl = data.get("results", [])
        if not vysl:
            continue
        top = max(vysl, key=lambda x: x.get("popularity", 0))
        if najlepsi is None or top.get("popularity", 0) > najlepsi[0].get("popularity", 0):
            najlepsi = (top, endpoint)

    if not najlepsi:
        return prazdne
    top, endpoint = najlepsi
    if endpoint == "tv":
        en = top.get("original_name") or top.get("name", "")
        cisty = top.get("name", "") or en
        rok = (top.get("first_air_date", "") or "")[:4]
    else:
        en = top.get("original_title") or top.get("title", "")
        cisty = top.get("title", "") or en
        rok = (top.get("release_date", "") or "")[:4]
    poster = top.get("poster_path")
    plagat = f"https://image.tmdb.org/t/p/w500{poster}" if poster else ""
    backdrop = top.get("backdrop_path")
    fanart = f"https://image.tmdb.org/t/p/w1280{backdrop}" if backdrop else ""
    popis = top.get("overview", "") or ""

    cz = ""
    tid = top.get("id")
    if tid:
        det = _get(f"https://api.themoviedb.org/3/{endpoint}/{tid}",
                   {"api_key": API_KEY, "language": "cs-CZ"})
        cz = det.get("title") or det.get("name") or ""
        if not popis and det.get("overview"):
            popis = det.get("overview")

    return {"en": en or query, "rok": rok, "cz": cz, "cisty": cisty or query,
            "plagat": plagat, "fanart": fanart, "popis": popis}
