"""Úložisko rozpozeraných (continue watching) — JSON v addon_data.

Sleduje: ident, názov, plagát, sub_query, pozícia, dĺžka, čas.
"""
import json
import time

import xbmcaddon
import xbmcvfs

_ADDON = xbmcaddon.Addon()
_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_SUBOR = _DIR + "watched.json"


def _nacitaj_raw():
    try:
        if xbmcvfs.exists(_SUBOR):
            with xbmcvfs.File(_SUBOR) as f:
                return json.loads(f.read() or "{}")
    except Exception:
        pass
    return {}


def _zapis(data):
    try:
        if not xbmcvfs.exists(_DIR):
            xbmcvfs.mkdirs(_DIR)
        with xbmcvfs.File(_SUBOR, "w") as f:
            f.write(bytearray(json.dumps(data).encode("utf-8")))
    except Exception:
        pass


def uloz(ident, nazov, plagat, sub, position, total):
    if not ident:
        return
    data = _nacitaj_raw()
    finished = total > 0 and position >= total * 0.92
    if finished:
        data.pop(ident, None)  # dopozerané → preč z rozpozeraných
    else:
        data[ident] = {
            "ident": ident, "nazov": nazov, "plagat": plagat, "sub": sub,
            "position": int(position), "total": int(total), "cas": time.time(),
        }
    _zapis(data)


def zoznam():
    """Rozpozerané položky, najnovšie prvé (len s rozumnou pozíciou)."""
    data = _nacitaj_raw()
    polozky = [v for v in data.values() if v.get("position", 0) > 30]
    polozky.sort(key=lambda x: x.get("cas", 0), reverse=True)
    return polozky


def odstran(ident):
    data = _nacitaj_raw()
    if data.pop(ident, None) is not None:
        _zapis(data)
