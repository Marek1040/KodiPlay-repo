"""Trakt.tv + TMDB — populárne / trending filmy a seriály s plagátmi.

Používa iba vstavané moduly (urllib). Vývojárske API kľúče (rovnaké ako web appka).
"""
import json
import urllib.request
import urllib.parse

TRAKT_CLIENT_ID = "abe2b8aca6510fa3a45e3e19abf7837e7c4018e5d1aa091b520f81714d4b9363"
TRAKT_BASE = "https://api.trakt.tv"
TMDB_API_KEY = "5eba3d51d36e1710cb48aeb47ec94643"

_tmdb_cache = {}


def _get(url, headers=None, timeout=8):
    try:
        h = {"User-Agent": "KodiPlay/1.0"}
        if headers:
            h.update(headers)
        req = urllib.request.Request(url, headers=h)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _tmdb_detail(tmdb_id, je_tv):
    """Vráti (nazov, plagat, rating, popis, fanart) z TMDB — cachované."""
    if not tmdb_id:
        return "", "", "", "", ""
    kluc = ("tv" if je_tv else "movie", tmdb_id)
    if kluc in _tmdb_cache:
        return _tmdb_cache[kluc]
    typ = "tv" if je_tv else "movie"
    url = f"https://api.themoviedb.org/3/{typ}/{tmdb_id}?api_key={TMDB_API_KEY}&language=sk-SK"
    data = _get(url) or {}
    # ak SK nemá popis, skús CZ
    if not data.get("overview"):
        cz = _get(url.replace("sk-SK", "cs-CZ")) or {}
        if cz.get("overview"):
            data = cz or data
    nazov = data.get("name") or data.get("title") or ""
    poster = data.get("poster_path")
    plagat = f"https://image.tmdb.org/t/p/w500{poster}" if poster else ""
    backdrop = data.get("backdrop_path")
    fanart = f"https://image.tmdb.org/t/p/w1280{backdrop}" if backdrop else ""
    rating = str(int(data.get("vote_average", 0) * 10)) if data.get("vote_average") else ""
    popis = data.get("overview", "") or ""
    vysl = (nazov, plagat, rating, popis, fanart)
    _tmdb_cache[kluc] = vysl
    return vysl


def _spracuj(polozky, je_tv, vnoreny):
    out = []
    for it in polozky:
        if vnoreny:  # trending → {"movie": {...}} / {"show": {...}}
            d = it.get("show" if je_tv else "movie", it)
        else:        # popular → priamo objekt
            d = it
        trakt_nazov = d.get("title", "")
        rok = d.get("year", "")
        tmdb_id = d.get("ids", {}).get("tmdb")
        lok_nazov, plagat, rating, popis, fanart = _tmdb_detail(tmdb_id, je_tv)
        out.append({
            "nazov": (lok_nazov or trakt_nazov) + (f" ({rok})" if rok else ""),
            "cisty_nazov": lok_nazov or trakt_nazov,
            "en_nazov": trakt_nazov,
            "rok": str(rok or ""),
            "plagat": plagat,
            "fanart": fanart,
            "rating": rating,
            "popis": popis,
            "media_type": "tv" if je_tv else "movie",
        })
    return out


def _zoznam(path, je_tv=False, vnoreny=False, limit=20):
    headers = {"Content-Type": "application/json",
               "trakt-api-version": "2", "trakt-api-key": TRAKT_CLIENT_ID}
    sep = '&' if '?' in path else '?'
    data = _get(f"{TRAKT_BASE}{path}{sep}page=1&limit={limit}", headers=headers)
    if not data:
        return []
    return _spracuj(data, je_tv, vnoreny)


# Žánre (Trakt slug → SK názov)
ZANRE = [
    ("action", "Akčné"), ("adventure", "Dobrodružné"), ("animation", "Animované"),
    ("comedy", "Komédie"), ("crime", "Krimi"), ("documentary", "Dokumentárne"),
    ("drama", "Drámy"), ("fantasy", "Fantasy"), ("horror", "Horory"),
    ("mystery", "Mysteriózne"), ("romance", "Romantické"),
    ("science-fiction", "Sci-Fi"), ("thriller", "Trilery"),
]


def popularne_filmy():
    return _zoznam("/movies/popular", je_tv=False, vnoreny=False)

def trending_filmy():
    return _zoznam("/movies/trending", je_tv=False, vnoreny=True)

def anticipovane_filmy():
    return _zoznam("/movies/anticipated", je_tv=False, vnoreny=True)

def popularne_serialy():
    return _zoznam("/shows/popular", je_tv=True, vnoreny=False)

def trending_serialy():
    return _zoznam("/shows/trending", je_tv=True, vnoreny=True)

def anticipovane_serialy():
    return _zoznam("/shows/anticipated", je_tv=True, vnoreny=True)

def top_filmy():  # najsledovanejšie za týždeň
    return _zoznam("/movies/watched/weekly", je_tv=False, vnoreny=True, limit=20)

def top_serialy():
    return _zoznam("/shows/watched/weekly", je_tv=True, vnoreny=True, limit=20)

def filmy_zaner(slug):
    return _zoznam(f"/movies/popular?genres={slug}", je_tv=False, vnoreny=False)

def serialy_zaner(slug):
    return _zoznam(f"/shows/popular?genres={slug}", je_tv=True, vnoreny=False)

def cz_sk_filmy():  # filmy s českou/slovenskou stopou
    return _zoznam("/movies/watched/yearly?languages=cs,sk", je_tv=False, vnoreny=True, limit=40)

def cz_sk_serialy():
    return _zoznam("/shows/watched/yearly?languages=cs,sk", je_tv=True, vnoreny=True, limit=40)
